﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentDetails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetupDataGridView();

        }

        private void SetupDataGridView()
        {
            
            DataGridView dataGridView = dataGridView1;
            //dataGridView.Dock = DockStyle.Fill;

            // Add empty row for startup
            dataGridView.Rows.Add("", "", "", "", "", "", "", "");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double amount;

            if (double.TryParse(amountInput.Text.ToString(), out amount))
            {
                string Name = nameInput.Text.ToString();
                string regNumber = regInput.Text.ToString();
                string gender = genderInput.Text.ToString();
                string rooms = "";

                double esadza, residence, fees; // 10% esadza, 20% residence, 70% fees

                esadza = .1 * amount;
                residence = .2 * amount;
                fees = amount - (esadza + residence);

                //Console.WriteLine(esadza);
                //Console.WriteLine(residence);
                Console.WriteLine(amount);

               

                if (amount < 100)
                {
                    // 20 person capacity rooms
                    rooms = "20 person capacity rooms";
                }
                else if (amount >= 100 && amount <= 200)
                {
                    // double rooms
                    rooms = "Double rooms";
                }
                else
                {
                    // single room
                    rooms = "Single room";
                }
                // set cells esadza, residence, fees respectively
                dataGridView1.Rows[0].Cells[0].Value = Name;
                dataGridView1.Rows[0].Cells[1].Value = regNumber;
                dataGridView1.Rows[0].Cells[2].Value = gender;
                dataGridView1.Rows[0].Cells[3].Value = amount;
                dataGridView1.Rows[0].Cells[4].Value = rooms;
                dataGridView1.Rows[0].Cells[5].Value = residence;
                dataGridView1.Rows[0].Cells[6].Value = fees;
                dataGridView1.Rows[0].Cells[7].Value = esadza;

                
            }
            //dataGridView1.Rows[1].Cells[1].Value = rooms; // set the bottom middle cell value
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void roomsLabel_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
